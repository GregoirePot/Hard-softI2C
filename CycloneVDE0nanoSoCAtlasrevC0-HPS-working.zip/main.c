
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include <stdbool.h>
#include "mmap_hw_regs.h"
#include "led.h"
#include "dipsw_pio.h"
#include "key_pio.h"
#include "pio_0_pio.h"
#include "led_gpio.h"
#include "key_gpio.h"


int main(int argc, char **argv) {
	
	unsigned int dipsw_reg = 0;
	unsigned int key_pio_reg = 0;
	unsigned int pio_0_reg = 0;
	MMAP_open();
	LEDR_setup();
	DIPSW_setup();
	KEY_PIO_setup();
	PIO_0_setup();
	LED_gpio_setup();
	KEY_gpio_setup();

	while(1)
	{
	int i;
		dipsw_reg = DIPSW_read();
		printf ("dipsw_reg  %s\n", DIPSW_binary_string( dipsw_reg ) );
		key_pio_reg = KEY_PIO_read();
		printf ("key_pio_reg  %s\n", KEY_PIO_binary_string( key_pio_reg ) );
		pio_0_reg = PIO_0_read();
		printf ("pio_0_reg %s\n", DIPSW_binary_string( pio_0_reg  ) );
		printf("LED gpio on\r\n");
		LED_gpio_on();
		printf("LED ON \r\n");
		for(i=0;i<=8;i++){
			LEDR_LightCount(i);
			usleep(100*1000);
		}
		printf("LED gpio off\r\n");
		LED_gpio_off();
		printf("LED OFF \r\n");
		for(i=0;i<=8;i++){
			LEDR_OffCount(i);
			usleep(100*1000);
		}
		printf("change DIPSW then press KEY gpio\r\n");
		while( KEY_gpio_released() ) {
			usleep(100*1000);
		}
		dipsw_reg = DIPSW_read();
		printf ("dipsw_reg  %s\n", DIPSW_binary_string( dipsw_reg ) );
		pio_0_reg = PIO_0_read();
		printf ("pio_0_reg %s\n", DIPSW_binary_string( pio_0_reg  ) );
		printf("KEY gpio pressed\r\n");		
	}
	MMAP_close();
	
	return 0;
}