// led_gpio
// uses the HPS LED directly from software

#ifndef LED_GPIO_H_
#define LED_GPIO_H_

void LED_gpio_setup();

void LED_gpio_on();

void LED_gpio_off();

#endif /*LED_GPIO_H_*/
